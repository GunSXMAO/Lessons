from fastapi import APIRouter

router = APIRouter(prefix="/user", tags=["user"])

@router.get("/", status_code=200)
def all_users():
    return {}

@router.get("/{user_id}", status_code=200)
def user_by_id(user_id: int):
    return {}

@router.post("/create", status_code=201)
def create_user():
    return {}

@router.put("/update", status_code=200)
def update_user():
    return {}

@router.delete("/delete/{user_id}", status_code=204)
def delete_user(user_id: int):
    return {}