from fastapi import APIRouter

router = APIRouter(prefix="/task", tags=["task"])

@router.get("/", status_code=200)
def all_tasks():
    return {}

@router.get("/{task_id}", status_code=200)
def task_by_id(task_id: int):
    return {}

@router.post("/create", status_code=201)
def create_task():
    return {}

@router.put("/update", status_code=200)
def update_task():
    return {}

@router.delete("/delete/{task_id}", status_code=204)
def delete_task(task_id: int):
    return {}