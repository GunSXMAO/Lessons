from fastapi import FastAPI
from app.user import router as user_router
from app.backend.db import engine, Base
from app.models import User, Task

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Welcome to Taskmanager"}

# Создание таблиц в базе данных
Base.metadata.create_all(bind=engine)

app.include_router(user_router)