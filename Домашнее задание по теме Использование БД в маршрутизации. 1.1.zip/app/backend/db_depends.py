from sqlalchemy.orm import Session
from .db import get_db

def get_db():
    db = get_db()
    try:
        yield db
    finally:
        db.close()