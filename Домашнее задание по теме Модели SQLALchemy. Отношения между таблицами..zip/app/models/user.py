from fastapi import APIRouter
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.backend.db import Base

router = APIRouter(prefix="/user", tags=["user"])

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    firstname = Column(String)
    lastname = Column(String)
    age = Column(Integer)
    slug = Column(String, unique=True, index=True)

    tasks = relationship("Task", back_populates="user")

@router.get("/", status_code=200)
def all_users():
    return {}

@router.get("/{user_id}", status_code=200)
def user_by_id(user_id: int):
    return {}

@router.post("/create", status_code=201)
def create_user():
    return {}

@router.put("/update", status_code=200)
def update_user():
    return {}

@router.delete("/delete/{user_id}", status_code=204)
def delete_user(user_id: int):
    return {}