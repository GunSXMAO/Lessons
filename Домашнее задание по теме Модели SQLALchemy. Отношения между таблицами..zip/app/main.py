from fastapi import FastAPI
from app.models.user import router as user_router
from app.models.task import router as task_router
from app.backend.db import engine, Base

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Welcome to Taskmanager"}

# Создание таблиц в базе данных
Base.metadata.create_all(bind=engine)

app.include_router(task_router)
app.include_router(user_router)